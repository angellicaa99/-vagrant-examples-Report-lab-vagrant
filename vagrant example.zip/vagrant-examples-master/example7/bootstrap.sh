#!/bin/bash

sudo apt-get --yes update
sudo apt-get --yes upgrade
sudo apt-get --yes install puppet

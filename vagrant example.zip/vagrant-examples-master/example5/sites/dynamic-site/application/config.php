<?php
define('ROOT_DIR', dirname(getcwd()));
define('APPLICATION_DIR', ROOT_DIR . '/application');

define('DB_DSN', 'mysql:host=db;dbname=dynamic');
define('DB_USER', 'webuser');
define('DB_PASS', 'vagrantrocks');

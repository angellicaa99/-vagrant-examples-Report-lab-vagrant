<?php
define('ROOT_DIR', dirname(getcwd()));
define('APPLICATION_DIR', ROOT_DIR . '/application');

define('DB_DSN', 'mysql:host=db;dbname=dynamic');
define('DB_USER', 'webuser');
define('DB_PASS', 'vagrantrocks');

define('CACHE_HOST', 'cache');
define('CACHE_PORT', 11211);
